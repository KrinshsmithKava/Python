course = "Python Programming"
print(len(course))
print(course[0])
print(course[-1])
print(course[0:1])
print(course[0:3])
print(course[0:])
print(course[:3])
print(course[:])

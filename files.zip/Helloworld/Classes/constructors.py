class point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def draw(self):
        print(f"point ({self.x}, {self.y})")


point = point(1, 2)
point.draw()

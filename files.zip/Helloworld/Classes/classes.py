x = 1
print(type(x))

# class : blue print for creating new object
# object : instance of a class

# example class : human
# object : john, mary, jack

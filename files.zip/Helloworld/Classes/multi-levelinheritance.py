class Animal:
    def eat(self):
        print("eat")


class Bird(Animal):
    def fly(self):
        print("fly")


class Chicken(Bird):
    def fly(self):
        print("fly")

# Employee - Person - LivingCreature - Thing

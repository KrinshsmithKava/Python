class point:
    def draw(self):
        print("draw")


point = point()
print(type(point))
print(isinstance(point, int))

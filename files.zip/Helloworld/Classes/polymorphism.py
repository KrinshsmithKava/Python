from abc import ABC, abstractmethod


class UIControl(ABC):
    @abstractmethod
    def draw(self):
        pass


class TextBox(UIControl):
    def draw(self):
        print("TextBox")


class DropDownList(UIControl):
    def draw(self):
        print("DropDownList")


def draw(controls):
    for control in controls:
        control.draw()


ddl = DropDownList()
textbox = TextBox()
draw([ddl, textbox])

# Example of Polymorphism

# class Dog:
#     def speak(self):
#         print("Bark")


# class Cat:
#     def speak(self):
#         print("Meow")


# dog = Dog()
# cat = Cat()

# dog.speak()
# cat.speak()

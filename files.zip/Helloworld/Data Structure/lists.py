letters = ["a", "b", "c"]
matrix = [[0, 1], [2, 3]]
zeros = [0] * 5
# combined = zeros + letters
numbers = list(range(20))
chars = list("Hello World")
print(chars)

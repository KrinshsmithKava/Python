x = 10
y = 11

# z = x
# x = y
# y = z

x, y = y, x

# a, b = 1, 2
# print("a", a)
# print("b", b)

print("x", x)
print("y", y)

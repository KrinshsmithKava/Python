letters = ["a", "b", "c", "d"]
letters[0] = "A"
print(letters[0:3])
print(letters[::1])

# numbers = list(range(20))
# print(numbers[::-1])

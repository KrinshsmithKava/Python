# numbers = [1, 2, 3]
# first, second = numbers

# first = numbers[0]
# second = numbers[1]
# third = numbers[2]

numbers = [1, 2, 3, 4, 4, 4, 4, 9]
first, *other, last = numbers
print(first, last)
print(other)

# def multiply(*numbers):

# multiply(1, 2, 3, 4, 5)

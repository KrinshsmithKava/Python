letters = ["a", "b", "c"]
# items = (0, "a")
# index, letter = items
for index, letter in enumerate(letters):
    print(index, letter)

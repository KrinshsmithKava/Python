
Course = "     Python Programming"

print(Course.upper())
print(Course.lower())
print(Course.title())
print(Course.strip())
print(Course.lstrip())
print(Course.rstrip())
print(Course.find("ing"))
print(Course.find("Ing"))
print(Course.replace("P", "C"))
print("Pro" in Course)
print("swift" not in Course)

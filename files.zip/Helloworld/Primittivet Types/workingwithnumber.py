
import math


print(round(2.9))
print(abs(-2.9))

print(math.ceil(2.2))

Students_Count = 1000
rating = 4.99
is_Published = True
Course_Name = "Python Programming"
print(Students_Count)

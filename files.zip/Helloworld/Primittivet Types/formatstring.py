first = "Mosh"
last = "Hamedni"
# full = first + " " + last
full = f"{len(first)} {len(last)} {2+2}"

print(full)

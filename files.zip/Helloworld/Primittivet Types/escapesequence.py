
#   \"
#   \'
#   \\
#   \n

# course = "Python \"Programming"
# course = "Python \'Programming"
# course = "Python \\Programming"
course = "Python \n Programming"

print(course)

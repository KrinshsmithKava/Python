
# x = input("x :")

# y = int(x) + 1

# print(f"x : {x}, Y : {y}")

# name = input("Name :")
# surname = "Gujarati"

# print(f"name : {name},surname : {surname}")

# int(x)
# float(x)
# bool(x)
# str(x)


a = input("first number: ")
b = input("second number: ")

cal = int(a) + int(b)

print(f"first number: {a}, second number: {b}\n total: {cal}")

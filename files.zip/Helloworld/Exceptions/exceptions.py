age = int(input("age: "))

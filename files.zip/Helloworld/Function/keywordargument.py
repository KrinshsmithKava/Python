def increment(number, by):
    return number + by


# result = increment(2, 1)
# print(result)

# print(increment(2, 1))

print(increment(2, by=1))

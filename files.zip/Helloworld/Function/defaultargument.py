def increment(number, by=1):
    return number + by


print(increment(2))

def save_user(**user):
    print(user["id"])
    # print(user["name"])
    # print(user["age"])


save_user(id=1, name="Jhon", age=22)

# it will show how dictionary is work

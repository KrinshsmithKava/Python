def greet():
    print("Hi There")
    print("Welcome aboard")


greet()

# from sales import calc_shipping, calc_tax
# import sales

# sales.calc_shipping()

# calc_shipping()
# calc_tax


# from ecommerce.sales import calc_tax, calc_shipping
# from ecommerce import sales

from ecommerce.shopping import sales

# print(dir(sales))
# print(sales.__name__)
# print(sales.__package__)
# print(sales.__file__)

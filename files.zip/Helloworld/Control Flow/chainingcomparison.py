
age = 18
if 18 <= age < 65:
    print("Eligible")

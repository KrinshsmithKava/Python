
# number = 100
# while number > 0:
#     print(number)
#     number //= 5


# number = 0
# while number < 100:
#     print(number)
#     number += 1


command = ""

while command.lower() != "quit":
    command = input(">")
    print("Echo", command)

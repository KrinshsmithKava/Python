
# age = 19
# message = "Elegible" if age >= 18 else "not Elegible"
# print(message)


number = int(input("enter the number "))
result = "the number is even" if number % 2 == 0 else "odd number"
print(f"The number is {result}")

a = 10 > 10
print(a)
b = "bag" > "apple"
print(b)

c = ord("b")
print(c)


""" <
>
<=
>=
==
!= """

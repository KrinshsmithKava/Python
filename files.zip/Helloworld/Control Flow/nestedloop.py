
# for x in range(5):
#     for y in range(3):
#         print(f"{x},{y}")


# for x in range(5):
#     for y in range(5):
#         print(f"{x},{y}", end=" ")
#     print()


# for x in range(10):
#     for y in range(5):
#         print(f"{x},{y}", end=" ")
#     print()

for x in range(10):
    for y in range(5):
        print(f"{x+1},{y+1}", end=" ")
    print()

if 10 == "10":
    print("a")
elif "bag" > "apple" and "bag" > "cat":
    print("b")
elif 10 > 9 or 10 < 2:
    print("c")

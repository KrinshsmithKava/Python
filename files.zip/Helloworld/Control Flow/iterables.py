
print(type(5))
print(type(range(5)))


# itrables
# for x in "python":
#     print(x)

# for x in [1, 2, 3, 4]:
#     print(x)


# for x in ["Krish", "Gujarati", "21"]:
#     print(x)

# for x in range(1, 4):
#     print(x)

shopping_cart = ["Mobile", "TV", "Laptop"]
for item in shopping_cart:
    print(item)

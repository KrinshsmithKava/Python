
Successful = True

for number in range(3):
    print("Attempt")
    if Successful:
        print("successful")
        break
else:
    print("Attempt 3 times")

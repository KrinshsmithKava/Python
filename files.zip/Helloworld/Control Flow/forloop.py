 for number in range(1, 20,  3):
    print("Attempt", number, number * ".")
